// toggleNavbar.js

$("#navbar-toggle-button").click(function () {
  $(".navbar").toggleClass("hidden");
});
