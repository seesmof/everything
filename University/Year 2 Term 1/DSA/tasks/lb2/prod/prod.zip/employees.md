Bernard Patton,Software Engineer
Ethan Casey,Product Manager
Lenora Price,Data Scientist
Christopher White,UX Designer
Kenneth Burns,Web Developer
John Doe,Software Engineer
